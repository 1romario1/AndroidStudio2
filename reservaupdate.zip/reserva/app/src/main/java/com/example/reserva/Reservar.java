package com.example.reserva;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class Reservar extends AppCompatActivity implements View.OnClickListener{
    Button btnregresar;

    Button btnFecha1;
    Button btnFecha2;
    Button btnFecha3;

    EditText editTextFecha1;
    EditText editTextFecha2;
    EditText editTextFecha3;

    private int dia,mes,año;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservar);

        btnregresar = findViewById(R.id.btnregresar);

        btnregresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Reservar.this,"good bye", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(Reservar.this,MainActivity.class));
            }

        });

        btnFecha1=(Button) findViewById(R.id.btnFecha1);
        btnFecha2=(Button) findViewById(R.id.btnFecha2);
        btnFecha3=(Button) findViewById(R.id.btnFecha3);

        editTextFecha1=(EditText) findViewById(R.id.editTextFecha1);
        editTextFecha2=(EditText) findViewById(R.id.editTextFecha2);
        editTextFecha3=(EditText) findViewById(R.id.editTextFecha3);


        btnFecha1.setOnClickListener(this);
        btnFecha2.setOnClickListener(this);
        btnFecha3.setOnClickListener(this);
        }
        @Override
        public void onClick(View v){
        if(v==btnFecha1){
        final Calendar c= Calendar.getInstance();
        dia=c.get(Calendar.DAY_OF_MONTH);
        mes=c.get(Calendar.MONTH);
        año=c.get(Calendar.YEAR);

            DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener(){
                @Override
                public void onDateSet(DatePicker view, int year,int monthOFYear,int dayOFMonth){
                    editTextFecha1.setText(dayOFMonth+"/"+(monthOFYear+1)+"/"+year);
                }
            }
            ,dia,mes,año);
            datePickerDialog.show();
        }
        if(v==btnFecha2){
            final Calendar c= Calendar.getInstance();
            dia=c.get(Calendar.DAY_OF_MONTH);
            mes=c.get(Calendar.MONTH);
            año=c.get(Calendar.YEAR);

            DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener(){
                @Override
                public void onDateSet(DatePicker view, int year,int monthOFYear,int dayOFMonth){
                    editTextFecha2.setText(dayOFMonth+"/"+(monthOFYear+1)+"/"+year);
                }
            }
                    ,dia,mes,año);
            datePickerDialog.show();

        }
        if(v==btnFecha3){
            final Calendar c= Calendar.getInstance();
            dia=c.get(Calendar.DAY_OF_MONTH);
            mes=c.get(Calendar.MONTH);
            año=c.get(Calendar.YEAR);

            DatePickerDialog datePickerDialog=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener(){
                @Override
                public void onDateSet(DatePicker view, int year,int monthOFYear,int dayOFMonth){
                    editTextFecha3.setText(dayOFMonth+"/"+(monthOFYear+1)+"/"+year);
                }
            }
                    ,dia,mes,año);
            datePickerDialog.show();

        }
        }
}